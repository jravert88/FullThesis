/*
 * Environment.h
 *
 *  Created on: Apr 30, 2013
 *      Author: adm85
 */

#ifndef ENVIRONMENT_H_
#define ENVIRONMENT_H_

namespace PAQ_SOQPSK {

	//--------------------------------------------------------------------------------------
	//                     CONSTANTS
	//--------------------------------------------------------------------------------------
	const unsigned int SYSTEM_HAS_GPU = 1;
	const unsigned int DEBUG_MODE = 1;

}


#endif /* ENVIRONMENT_H_ */
